====================================================
  SIMTS FULL DISASTER RECOVERY ARCHIVE
====================================================
Created At: 2026-08-20 21:20:43
Database Driver: postgresql+psycopg
Backup Strategy: Native PostgreSQL pg_dump (simts_postgres.sql), Portable SQL (database_export.sql) & JSON (database_export.json)

System Statistics at Backup:
  - Total Students: 2
  - Total Courses: 1
  - Total Certificates: 1
  - Total Marksheets: 1

Archive Contents:
  - simts_postgres.sql / database_export.sql: Database dumps
  - database_export.json: Structured JSON data of all records
  - uploads/: All certificate & marksheet PDF files

Restoration Steps (In case of server crash, attack, or data loss):
  1. Extract this zip archive.
  2. Copy the 'uploads/' folder into your SIMTS project root.
  3. Restore your database using either:
     - PostgreSQL: psql -U simts_user -d simts -f simts_postgres.sql
       (or execute database_export.sql in pgAdmin/psql)
     - SQLite: copy simts.db to instance/simts.db
  4. Start the SIMTS application.
====================================================
