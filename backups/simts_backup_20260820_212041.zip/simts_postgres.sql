--
-- PostgreSQL database dump
--

\restrict tAnlikXK6tyYbCBYB3XUvr8Yasxr8ICuz3gG1mes9sdi39svavpDOYtS4r2e2o8

-- Dumped from database version 18.4
-- Dumped by pg_dump version 18.4

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE IF EXISTS ONLY public.student DROP CONSTRAINT IF EXISTS student_course_id_fkey;
ALTER TABLE IF EXISTS ONLY public.marksheet DROP CONSTRAINT IF EXISTS marksheet_student_id_fkey;
ALTER TABLE IF EXISTS ONLY public.certificate DROP CONSTRAINT IF EXISTS certificate_student_id_fkey;
ALTER TABLE IF EXISTS ONLY public.audit_log DROP CONSTRAINT IF EXISTS audit_log_admin_id_fkey;
DROP INDEX IF EXISTS public.ix_student_student_id;
DROP INDEX IF EXISTS public.ix_student_marksheet_number;
DROP INDEX IF EXISTS public.ix_student_email;
DROP INDEX IF EXISTS public.ix_student_certificate_number;
DROP INDEX IF EXISTS public.ix_marksheet_marksheet_number;
DROP INDEX IF EXISTS public.ix_course_course_code;
DROP INDEX IF EXISTS public.ix_contact_message_email;
DROP INDEX IF EXISTS public.ix_certificate_certificate_number;
DROP INDEX IF EXISTS public.ix_admin_username;
ALTER TABLE IF EXISTS ONLY public.student DROP CONSTRAINT IF EXISTS student_pkey;
ALTER TABLE IF EXISTS ONLY public.marksheet DROP CONSTRAINT IF EXISTS marksheet_pkey;
ALTER TABLE IF EXISTS ONLY public.course DROP CONSTRAINT IF EXISTS course_pkey;
ALTER TABLE IF EXISTS ONLY public.contact_message DROP CONSTRAINT IF EXISTS contact_message_pkey;
ALTER TABLE IF EXISTS ONLY public.certificate DROP CONSTRAINT IF EXISTS certificate_pkey;
ALTER TABLE IF EXISTS ONLY public.audit_log DROP CONSTRAINT IF EXISTS audit_log_pkey;
ALTER TABLE IF EXISTS ONLY public.admin DROP CONSTRAINT IF EXISTS admin_pkey;
ALTER TABLE IF EXISTS public.student ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.marksheet ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.course ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.contact_message ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.certificate ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.audit_log ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.admin ALTER COLUMN id DROP DEFAULT;
DROP SEQUENCE IF EXISTS public.student_id_seq;
DROP TABLE IF EXISTS public.student;
DROP SEQUENCE IF EXISTS public.marksheet_id_seq;
DROP TABLE IF EXISTS public.marksheet;
DROP SEQUENCE IF EXISTS public.course_id_seq;
DROP TABLE IF EXISTS public.course;
DROP SEQUENCE IF EXISTS public.contact_message_id_seq;
DROP TABLE IF EXISTS public.contact_message;
DROP SEQUENCE IF EXISTS public.certificate_id_seq;
DROP TABLE IF EXISTS public.certificate;
DROP SEQUENCE IF EXISTS public.audit_log_id_seq;
DROP TABLE IF EXISTS public.audit_log;
DROP SEQUENCE IF EXISTS public.admin_id_seq;
DROP TABLE IF EXISTS public.admin;
SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: admin; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.admin (
    id integer NOT NULL,
    username character varying(80) NOT NULL,
    password_hash character varying(255) NOT NULL,
    is_active boolean NOT NULL,
    created_at timestamp without time zone NOT NULL,
    last_login timestamp without time zone
);


--
-- Name: admin_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.admin_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: admin_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.admin_id_seq OWNED BY public.admin.id;


--
-- Name: audit_log; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.audit_log (
    id integer NOT NULL,
    admin_id integer,
    action character varying(200) NOT NULL,
    target character varying(200),
    ip_address character varying(64),
    created_at timestamp without time zone NOT NULL
);


--
-- Name: audit_log_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.audit_log_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: audit_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.audit_log_id_seq OWNED BY public.audit_log.id;


--
-- Name: certificate; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.certificate (
    id integer NOT NULL,
    certificate_number character varying(100) NOT NULL,
    student_id integer NOT NULL,
    issue_date date NOT NULL,
    status character varying(30) NOT NULL,
    file_name character varying(255) NOT NULL,
    created_at timestamp without time zone NOT NULL
);


--
-- Name: certificate_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.certificate_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: certificate_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.certificate_id_seq OWNED BY public.certificate.id;


--
-- Name: contact_message; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.contact_message (
    id integer NOT NULL,
    name character varying(200) NOT NULL,
    email character varying(200) NOT NULL,
    subject character varying(300),
    message text NOT NULL,
    status character varying(30) NOT NULL,
    created_at timestamp without time zone NOT NULL
);


--
-- Name: contact_message_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.contact_message_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: contact_message_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.contact_message_id_seq OWNED BY public.contact_message.id;


--
-- Name: course; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.course (
    id integer NOT NULL,
    course_code character varying(50) NOT NULL,
    course_name character varying(200) NOT NULL,
    duration character varying(100),
    eligibility character varying(500),
    description text,
    status character varying(30) NOT NULL,
    created_at timestamp without time zone NOT NULL
);


--
-- Name: course_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.course_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: course_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.course_id_seq OWNED BY public.course.id;


--
-- Name: marksheet; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.marksheet (
    id integer NOT NULL,
    marksheet_number character varying(100) NOT NULL,
    student_id integer NOT NULL,
    issue_date date NOT NULL,
    status character varying(30) NOT NULL,
    file_name character varying(255) NOT NULL,
    created_at timestamp without time zone NOT NULL
);


--
-- Name: marksheet_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.marksheet_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: marksheet_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.marksheet_id_seq OWNED BY public.marksheet.id;


--
-- Name: student; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.student (
    id integer NOT NULL,
    student_id character varying(80) NOT NULL,
    full_name character varying(200) NOT NULL,
    email character varying(200) NOT NULL,
    phone character varying(50),
    gender character varying(30),
    academic_session character varying(50),
    admission_date date,
    admission_status character varying(50) NOT NULL,
    completion_status character varying(50) NOT NULL,
    certificate_number character varying(100),
    certificate_issue_date date,
    course_id integer,
    marksheet_number character varying(100),
    marksheet_issue_date date
);


--
-- Name: student_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.student_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: student_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.student_id_seq OWNED BY public.student.id;


--
-- Name: admin id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.admin ALTER COLUMN id SET DEFAULT nextval('public.admin_id_seq'::regclass);


--
-- Name: audit_log id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_log ALTER COLUMN id SET DEFAULT nextval('public.audit_log_id_seq'::regclass);


--
-- Name: certificate id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.certificate ALTER COLUMN id SET DEFAULT nextval('public.certificate_id_seq'::regclass);


--
-- Name: contact_message id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contact_message ALTER COLUMN id SET DEFAULT nextval('public.contact_message_id_seq'::regclass);


--
-- Name: course id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.course ALTER COLUMN id SET DEFAULT nextval('public.course_id_seq'::regclass);


--
-- Name: marksheet id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.marksheet ALTER COLUMN id SET DEFAULT nextval('public.marksheet_id_seq'::regclass);


--
-- Name: student id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.student ALTER COLUMN id SET DEFAULT nextval('public.student_id_seq'::regclass);


--
-- Data for Name: admin; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.admin (id, username, password_hash, is_active, created_at, last_login) FROM stdin;
1	Smits_admin.15082026	scrypt:32768:8:1$J2t509uKXnT8SBWG$74765359ca97c4782135d572659ed58cb031715191d3ef2a2a7a14c70e91e1f4196372ba9cfe9ea63a3dcca1d567c9d729346f23fde212f35d716ac8d6f4ee06	t	2026-08-15 08:22:34.565048	2026-08-20 15:49:45.094698
\.


--
-- Data for Name: audit_log; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.audit_log (id, admin_id, action, target, ip_address, created_at) FROM stdin;
1	\N	LOGIN_FAILED	Simts@admin@15082026	127.0.0.1	2026-08-15 08:14:22.171494
2	\N	LOGIN_FAILED	Simts@admin@15082026	127.0.0.1	2026-08-15 08:21:22.750957
3	\N	ADMIN_CREATED	Smits_admin.15082026	127.0.0.1	2026-08-15 08:22:34.658508
4	1	LOGIN_SUCCESS	Smits_admin.15082026	127.0.0.1	2026-08-15 08:22:45.558909
5	1	CREATE_COURSE	SIMTS_C_101	127.0.0.1	2026-08-15 08:25:10.82374
6	1	CREATE_STUDENT	SIMS101	127.0.0.1	2026-08-15 08:25:36.651946
7	1	CREATE_STUDENT	SIMS102	127.0.0.1	2026-08-15 08:26:02.97851
8	1	UPLOAD_CERTIFICATE	C101_SMITS_01	127.0.0.1	2026-08-15 08:26:28.860861
9	1	LOGIN_SUCCESS	Smits_admin.15082026	127.0.0.1	2026-08-15 15:05:02.798508
10	1	LOGIN_SUCCESS	Smits_admin.15082026	127.0.0.1	2026-08-20 14:34:06.074978
11	1	EDIT_STUDENT	SIMS102 - Student Bot 2	127.0.0.1	2026-08-20 14:34:37.568481
12	1	UPLOAD_MARKSHEET	MS-2026-101	127.0.0.1	2026-08-20 14:37:10.417476
13	1	LOGIN_SUCCESS	Smits_admin.15082026	127.0.0.1	2026-08-20 15:49:45.108651
\.


--
-- Data for Name: certificate; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.certificate (id, certificate_number, student_id, issue_date, status, file_name, created_at) FROM stdin;
1	C101_SMITS_01	1	2026-08-15	valid	C101_SMITS_01.pdf	2026-08-15 08:26:28.823333
\.


--
-- Data for Name: contact_message; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.contact_message (id, name, email, subject, message, status, created_at) FROM stdin;
1	Bot	bot@gmail.com	Test only	Hii! Heloo world	read	2026-08-15 08:28:51.621363
\.


--
-- Data for Name: course; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.course (id, course_code, course_name, duration, eligibility, description, status, created_at) FROM stdin;
1	SIMTS_C_101	Communication Skills	1 YEAR	12th Passèd	This is a Course regarding Communication skills, you will learn speaking skills and presentation skills. This is a dummy description of a course.	active	2026-08-15 08:25:10.771996
\.


--
-- Data for Name: marksheet; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.marksheet (id, marksheet_number, student_id, issue_date, status, file_name, created_at) FROM stdin;
1	MS-2026-101	1	2026-08-20	valid	marksheet_MS-2026-101.pdf	2026-08-20 14:37:10.417476
\.


--
-- Data for Name: student; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.student (id, student_id, full_name, email, phone, gender, academic_session, admission_date, admission_status, completion_status, certificate_number, certificate_issue_date, course_id, marksheet_number, marksheet_issue_date) FROM stdin;
2	SIMS102	Student Bot 2	studentbot2@gmail.com	8888888888		2026	2026-08-15	cancelled	ongoing	\N	\N	1	\N	\N
1	SIMS101	Student Bot 1	studentbot1@gmail.com	9999999999	\N	2026	2026-08-15	active	ongoing	C101_SMITS_01	2026-08-15	1	MS-2026-101	2026-08-20
\.


--
-- Name: admin_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.admin_id_seq', 1, true);


--
-- Name: audit_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.audit_log_id_seq', 13, true);


--
-- Name: certificate_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.certificate_id_seq', 1, true);


--
-- Name: contact_message_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.contact_message_id_seq', 33, true);


--
-- Name: course_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.course_id_seq', 1, true);


--
-- Name: marksheet_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.marksheet_id_seq', 1, true);


--
-- Name: student_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.student_id_seq', 2, true);


--
-- Name: admin admin_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.admin
    ADD CONSTRAINT admin_pkey PRIMARY KEY (id);


--
-- Name: audit_log audit_log_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT audit_log_pkey PRIMARY KEY (id);


--
-- Name: certificate certificate_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.certificate
    ADD CONSTRAINT certificate_pkey PRIMARY KEY (id);


--
-- Name: contact_message contact_message_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contact_message
    ADD CONSTRAINT contact_message_pkey PRIMARY KEY (id);


--
-- Name: course course_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.course
    ADD CONSTRAINT course_pkey PRIMARY KEY (id);


--
-- Name: marksheet marksheet_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.marksheet
    ADD CONSTRAINT marksheet_pkey PRIMARY KEY (id);


--
-- Name: student student_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.student
    ADD CONSTRAINT student_pkey PRIMARY KEY (id);


--
-- Name: ix_admin_username; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_admin_username ON public.admin USING btree (username);


--
-- Name: ix_certificate_certificate_number; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_certificate_certificate_number ON public.certificate USING btree (certificate_number);


--
-- Name: ix_contact_message_email; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_contact_message_email ON public.contact_message USING btree (email);


--
-- Name: ix_course_course_code; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_course_course_code ON public.course USING btree (course_code);


--
-- Name: ix_marksheet_marksheet_number; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_marksheet_marksheet_number ON public.marksheet USING btree (marksheet_number);


--
-- Name: ix_student_certificate_number; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_student_certificate_number ON public.student USING btree (certificate_number);


--
-- Name: ix_student_email; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_student_email ON public.student USING btree (email);


--
-- Name: ix_student_marksheet_number; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_student_marksheet_number ON public.student USING btree (marksheet_number);


--
-- Name: ix_student_student_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_student_student_id ON public.student USING btree (student_id);


--
-- Name: audit_log audit_log_admin_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT audit_log_admin_id_fkey FOREIGN KEY (admin_id) REFERENCES public.admin(id);


--
-- Name: certificate certificate_student_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.certificate
    ADD CONSTRAINT certificate_student_id_fkey FOREIGN KEY (student_id) REFERENCES public.student(id);


--
-- Name: marksheet marksheet_student_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.marksheet
    ADD CONSTRAINT marksheet_student_id_fkey FOREIGN KEY (student_id) REFERENCES public.student(id);


--
-- Name: student student_course_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.student
    ADD CONSTRAINT student_course_id_fkey FOREIGN KEY (course_id) REFERENCES public.course(id);


--
-- PostgreSQL database dump complete
--

\unrestrict tAnlikXK6tyYbCBYB3XUvr8Yasxr8ICuz3gG1mes9sdi39svavpDOYtS4r2e2o8

